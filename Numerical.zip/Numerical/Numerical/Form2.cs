﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using org.mariuszgromada.math.mxparser;



namespace Numerical
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Calculate_Click(object sender, EventArgs e)
        {


            //clear
            textBoxerror.Text = "";
            textBoxresult.Text = "";
            textBoxresultsimp.Text = "";
            textBoxerrorsimp.Text = "";
            feedback.Text = "";

            double a = 0, b = 0, n = 0, deltax = 0;
            double x = 0;
            string m = "";
            double resulta = 0, resultb = 0, resultc = 0;


            try
            {

                a = Convert.ToDouble(textBoxa.Text);
                b = Convert.ToDouble(textBoxb.Text);
                n = Convert.ToDouble(textBox1.Text);
                m = Convert.ToString(textBoxfx.Text);

            }
            catch (Exception)
            {
                feedback.Text = Convert.ToString("insufficient input or wrong input ( example input x^2, 2*x, cos(x), 1/(2*x) )");
                
            }

                
            deltax = (b - a) / n;
            double result;


            for (int i = 0; i <= n; ++i)
            {

                if (i == 0)
                {
                    x = a + (deltax * i);

                    Argument pol = new Argument("x", x);
                    Expression f = new Expression(m, pol);
                    resulta = f.calculate();

                }
                else if (i == n)
                {
                    x = a + (deltax * i);
                    Argument pol = new Argument("x", x);
                    Expression f = new Expression(m, pol);
                    resultb = f.calculate();
                }
                else
                {
                    x = a + (deltax * i);
                    Argument pol = new Argument("x", x);
                    Expression f = new Expression(m, pol);
                    resultc += 2 * f.calculate();

                }

            }


            result = (resulta + resultb + resultc) * (deltax / 2);
            textBoxresult.Text = Convert.ToString(result);


            //GETTING ERROR PERCENTAGE


            n++;
            double resultae = 0, resultbe = 0, resultce = 0, deltaxe = 0;


            deltaxe = (b - a) / n;
            double resulte, resultfinalerror;


            for (int i = 0; i <= n; ++i)
            {

                if (i == 0)
                {
                    x = a + (deltaxe * i);

                    Argument pol = new Argument("x", x);
                    Expression f = new Expression(m, pol);
                    resultae = f.calculate();

                }
                else if (i == n)
                {
                    x = a + (deltaxe * i);
                    Argument pol = new Argument("x", x);
                    Expression f = new Expression(m, pol);
                    resultbe = f.calculate();
                }
                else
                {
                    x = a + (deltaxe * i);
                    Argument pol = new Argument("x", x);
                    Expression f = new Expression(m, pol);
                    resultce += 2 * f.calculate();

                }

            }


            resulte = (resultae + resultbe + resultce) * (deltaxe / 2);
            resultfinalerror = (Math.Abs(resulte - result) / result) * 100;

            textBoxerror.Text = Convert.ToString(resultfinalerror + "%");


            // simpson calculator


            n = 0;





            try
            {


                n = Convert.ToDouble(textBox1.Text);
            }
            catch (Exception)
            {
                feedback.Text = Convert.ToString("insufficient input or wrong input ( example input x^2, 2*x, cos(x), 1/(2*x), pi*(x) )");

            }








            


            double resultasimp = 0, resultbsimp = 0, resultcsimp = 0, deltaxsimp = 0, resultdsimp = 0;

            deltaxsimp = (b - a) / n;
            double resultsimp;


            if (n % 2 == 0)
            {
                for (int i = 0; i <= n; ++i)
                {
                    //x0
                    if (i == 0)
                    {
                        x = a + (deltaxsimp * i);

                        Argument pol = new Argument("x", x);
                        Expression f = new Expression(m, pol);
                        resultasimp = f.calculate();

                    }
                    // xn
                    else if (i == n)
                    {
                        x = a + (deltaxsimp * i);
                        Argument pol = new Argument("x", x);
                        Expression f = new Expression(m, pol);
                        resultbsimp = f.calculate();
                    }
                    //even
                    else if (i % 2 == 0 && i != n)
                    {
                        x = a + (deltaxsimp * i);
                        Argument pol = new Argument("x", x);
                        Expression f = new Expression(m, pol);
                        resultcsimp += 2 * f.calculate();


                    }

                    //odd
                    else
                    {
                        x = a + (deltaxsimp * i);
                        Argument pol = new Argument("x", x);
                        Expression f = new Expression(m, pol);
                        resultdsimp += 4 * f.calculate();

                    }


                }

                resultsimp = (resultasimp + resultbsimp + resultcsimp + resultdsimp) * (deltaxsimp / 3);
                textBoxresultsimp.Text = Convert.ToString(resultsimp);
            }
            else
            {
                feedback.Text = Convert.ToString("Input value of n = odd");
            }


            resultsimp = (resultasimp + resultbsimp + resultcsimp + resultdsimp) * (deltaxsimp / 3);

            //SIMP ERROR

            n = 0;




            try
            {


                n = Convert.ToDouble(textBox1.Text);
            }
            catch (Exception)
            {
                feedback.Text = Convert.ToString("insufficient input or wrong input ( example input x^2, 2*x, cos(x), 1/(2*x), pi*(x) )");

            }

            


            double resultasimperror = 0, resultbsimperror = 0, resultcsimperror = 0, deltaxsimperror = 0, resultdsimperror = 0;

            n += 2;

            deltaxsimperror = (b - a) / n;
            double resultsimperror;


            if (n % 2 == 0)
            {
                for (int i = 0; i <= n; ++i)
                {
                    //x0
                    if (i == 0)
                    {
                        x = a + (deltaxsimperror * i);

                        Argument pol = new Argument("x", x);
                        Expression f = new Expression(m, pol);
                        resultasimperror = f.calculate();

                    }
                    // xn
                    else if (i == n)
                    {
                        x = a + (deltaxsimperror * i);
                        Argument pol = new Argument("x", x);
                        Expression f = new Expression(m, pol);
                        resultbsimperror = f.calculate();
                    }
                    //even
                    else if (i % 2 == 0 && i != n)
                    {
                        x = a + (deltaxsimperror * i);
                        Argument pol = new Argument("x", x);
                        Expression f = new Expression(m, pol);
                        resultcsimperror += 2 * f.calculate();


                    }

                    //odd
                    else
                    {
                        x = a + (deltaxsimperror * i);
                        Argument pol = new Argument("x", x);
                        Expression f = new Expression(m, pol);
                        resultdsimperror += 4 * f.calculate();

                    }


                }

                resultsimperror = (resultasimperror + resultbsimperror + resultcsimperror + resultdsimperror) * (deltaxsimperror / 3);




                resultfinalerror = (Math.Abs(resultsimperror -resultsimp ) /resultsimp ) * 100;

                textBoxerrorsimp.Text = Convert.ToString(resultfinalerror+"%");


            }
            else
            {
                int dummy=0;
                dummy++;
            }
            if (textBoxerror.Text == "0%" || textBoxerrorsimp.Text == "0%")
            {
                feedback.Text = Convert.ToString("0% error occur when the correct approximation is obtained by the inputted value of n ");
            }



        
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void textBoxresultsimp_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
            Size size = TextRenderer.MeasureText(textBox1.Text, textBox1.Font);
            textBox1.Width = size.Width;
            textBox1.Height = size.Height;
           

        }

        private void textBoxb_TextChanged(object sender, EventArgs e)
        {

            Size haba = TextRenderer.MeasureText(textBoxb.Text, textBoxb.Font);
            textBoxb.Width = haba.Width;
            textBoxb.Height = haba.Height;
        }

        private void textBoxa_TextChanged(object sender, EventArgs e)
        {
            Size laki = TextRenderer.MeasureText(textBoxa.Text, textBoxa.Font);
            textBoxa.Width = laki.Width;
            textBoxa.Height = laki.Height;
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBoxerror.Text = "";
            textBoxresult.Text = "";
            textBoxresultsimp.Text = "";
            textBoxerrorsimp.Text = "";
            feedback.Text = "";
            textBoxa.Text = "";
            textBoxb.Text = "";
            textBoxfx.Text = "";
            textBox1.Text = "";
        }

        private void textBoxfx_TextChanged(object sender, EventArgs e)
        {
            Size laki1 = TextRenderer.MeasureText(textBoxfx.Text, textBoxfx.Font);
            textBoxfx.Width = laki1.Width;
            textBoxfx.Height = laki1.Height;
        }

        private void textBoxresult_TextChanged(object sender, EventArgs e)
        {
   
        }
    }
}
